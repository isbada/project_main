class Start:
    def __init__(self, row, col):
        self.display = 'X'
        self.row = row
        self.col = col

    def step(self, game):
        pass


class End:
    def __init__(self, row, col):
        self.display = 'Y'
        self.row = row
        self.col = col

    def step(self, game):
        pass


class Air:
    def __init__(self, row, col):
        self.display = ' '
        self.row = row
        self.col = col

    def step(self, game):
        pass


class Wall:
    def __init__(self, row, col):
        self.display = '*'
        self.row = row
        self.col = col

    def step(self, game):
        pass


class Fire:
    def __init__(self, row, col):
        self.display = 'F'
        self.row = row
        self.col = col

    def step(self, game):
        pass


class Water:
    def __init__(self, row, col):
        self.display = 'W'
        self.row = row
        self.col = col

    def step(self, game):
        pass


class Teleport:
    def __init__(self, row, col):
        self.display = 0  # You'll need to change this!
        self.row = row
        self.col = col

    def step(self, game):
        pass
