
from cells import (
    Start,
    End,
    Air,
    Wall,
    Fire,
    Water,
    Teleport
)


def read_lines(filename):
    """Read in a file, process them using parse(),
    and return the contents as a list of list of cells."""
    try:
        contents = []
        with open(filename) as fin:
            for line in fin:
                contents.append(line.strip())

        print(contents)
        return parse(contents)

    except FileNotFoundError:
        print('%s does not exist!' % (filename))
        quit()


def parse(lines):
    """Transform the input into a grid.

    Arguments:
        lines -- list of strings representing the grid

    Returns:
        list -- contains list of lists of Cells
    """
    M, N = len(lines), len(lines[0])
    grid = [[None] * N for _ in range(M)]

    for r in range(M):
        for c in range(N):
            symol = lines[r][c]
            if symol == 'X':
                grid[r][c] = Start(r, c)
            elif symol == 'Y':
                grid[r][c] = End(r, c)
            elif symol == ' ':
                grid[r][c] = Air(r, c)
            elif symol == '*':
                grid[r][c] = Wall(r, c)
            elif symol == 'F':
                grid[r][c] = Fire(r, c)
            elif symol == 'W':
                grid[r][c] = Wall(r, c)
            elif symol.isdigit():
                grid[r][c] = Teleport(r, c, symol)


if __name__ == '__main__':
    read_lines('board_simple.txt')
