from game_parser import parse


def test_parse():
    assert True


def run_tests():
    test_parse()
