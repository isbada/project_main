import os
import sys


class Start:
    def __init__(self, pos):
        self.display = 'X'
        self.col = pos[0]
        self.row = pos[1]

    def step(self, game):
        # has no step function
        pass


class End:
    def __init__(self, pos):
        self.display = 'Y'
        self.col = pos[0]
        self.row = pos[1]

    def step(self, game):
        # print the win message and exit the game

        game.player.move((self.col, self.row))
        if game.mode == 'P':
            game.output()
            print('You conquer the treacherous maze set up by the Fire Nation and reclaim the '
                  'Honourable Furious Forest Throne, restoring your hometown back to its former ' +
                  'glory of rainbow and sunshine! Peace reigns over the lands.\n')
            game.endMessage()
            print('=====================\n' +
                  '====== YOU WIN! =====\n' +
                  '=====================')
        else:
            game.endMessage()

        sys.exit()


class Air:
    def __init__(self, pos):
        self.display = ' '
        self.col = pos[0]
        self.row = pos[1]

    def step(self, game):
        # update the player position to the new air cell

        game.player.move((self.col, self.row))

        if game.mode == 'P':
            game.output()


class Wall:
    def __init__(self, pos):
        self.display = '*'
        self.col = pos[0]
        self.row = pos[1]

    def step(self, game):
        # if move is into wall, remove the move from the move list

        game.move_list.pop()
        if game.mode == 'P':
            game.output()
            print('You walked into a wall. Oof!\n')


class Fire:
    def __init__(self, pos):
        self.display = 'F'
        self.col = pos[0]
        self.row = pos[1]

    def step(self, game):
        # check if burnt or fire put out and display the respective message

        if game.player.num_water_buckets:
            game.player.decWaterBuckets()
            game.player.move((self.col, self.row))
            game.grid[self.row][self.col] = Air((
                self.col, self.row))  # convert to an air cell
            if game.mode == 'P':
                game.output()
                print('With your strong acorn arms, you throw a water bucket at the ' +
                      'fire. You acorn roll your way through the extinguished flames!\n')
        else:
            if game.mode == 'P':
                print('You step into the fires and watch your dreams disappear :(.\n' +
                      '\nThe Fire Nation triumphs! The Honourable Furious Forest is ' +
                      'reduced to a pile of ash and is scattered to the winds by ' +
                      'the next storm... You have been roasted.\n')
                game.endMessage()
                print('=====================\n' +
                      '====== YOU LOSE! ====\n' +
                      '=====================')
                sys.exit()


class Water:
    def __init__(self, pos):
        self.display = 'W'
        self.col = pos[0]
        self.row = pos[1]

    def step(self, game):
        # increase num_buckets and convert to an air block

        game.player.incWaterBuckets()
        game.player.move((self.col, self.row))
        game.grid[self.row][self.col] = Air((self.col, self.row))

        if game.mode == 'P':
            game.output()
            print('Thank the Honourable Furious Forest, you\'ve found ' +
                  'a bucket of water!\n')


class Teleport:
    def __init__(self, pos, num):
        self.display = str(num)
        self.col = pos[0]
        self.row = pos[1]
        self.teleport_num = num

    def step(self, game):
        # teleport player

        # loop through each cell in grid and check for the correct teleport cell
        for row in game.grid:
            for cell in row:
                '''
                using try in case the cell being checked is not a teleport block and hence
                does not have a teleport_num block
                '''
                try:
                    if cell.teleport_num == self.teleport_num and (cell.row != self.row and cell.col != self.col):
                        game.player.move((cell.col, cell.row))
                except:
                    pass

        if game.mode == 'P':
            game.output()
            print('Whoosh! The magical gates break Physics as we know it and opens a ' +
                  'wormhole through space and time.\n')


class Node:
    def __init__(self, cell):
        self.cell = cell
        self.neighbours = []
        self.visited = False
