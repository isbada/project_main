from game_parser import read_lines, nodeParse
from grid import grid_to_string
from player import Player
from cells import (
    Start,
    End,
    Air,
    Wall,
    Fire,
    Water,
    Teleport
)

import sys
import os


class Game:
    def __init__(self, filename, mode):
        self.grid = read_lines(filename)
        self.player = Player(self.posTypeFind(Start))
        self.move_list = []  # used to store the player moves
        self.mode = mode
        self.node_list = nodeParse(self.grid)

    def gameMove(self, move):
        # append the move to the move list and update the player position
        y = self.player.row
        x = self.player.col

        if move == 'w':
            self.move_list.append('w')
            self.posUpdate((self.grid[y - 1][x].col, self.grid[y - 1][x].row))

        elif move == 'a':
            self.move_list.append('a')
            self.posUpdate((self.grid[y][x - 1].col, self.grid[y][x - 1].row))

        elif move == 's':
            self.move_list.append('s')
            self.posUpdate((self.grid[y + 1][x].col, self.grid[y + 1][x].row))

        elif move == 'd':
            self.move_list.append('d')
            self.posUpdate((self.grid[y][x + 1].col, self.grid[y][x + 1].row))

        elif move == 'e':
            self.move_list.append('e')
            self.posUpdate((self.grid[y][x].col, self.grid[y][x].row))

        elif move == 'q':
            print('\nBye!')
            sys.exit()

        elif self.mode == 'P':
            print('\nPlease enter a valid move (w, a, s, d, e, q).\n')

    def posTypeFind(self, find):
        # takes in a class type and finds the first instance in the grid
        for row in self.grid:
            for cell in row:
                if type(cell) == find:
                    return (cell.col, cell.row)

    def output(self):
        # calls the grid to string function
        print(grid_to_string(self.grid, self.player))

    def posUpdate(self, pos):
        # calls the respective cell.step function for the new position
        cell = self.grid[pos[1]][pos[0]]

        if type(cell) == Air:
            Air.step(cell, self)
        elif type(cell) == Teleport:
            Teleport.step(cell, self)
        elif type(cell) == Water:
            Water.step(cell, self)
        elif type(cell) == Fire:
            Fire.step(cell, self)
        elif type(cell) == End:
            End.step(cell, self)
        else:
            Wall.step(cell, self)

    def endMessage(self):
        # display the end of game message
        print('You made {} moves.\n'.format(len(self.move_list)) +
              'Your moves: {}\n\n'.format(', '.join(self.move_list)))
