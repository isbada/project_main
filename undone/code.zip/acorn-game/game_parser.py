from cells import (
    Start,
    End,
    Air,
    Wall,
    Fire,
    Water,
    Teleport,
    Node
)

import sys


def read_lines(filename):
    """Read in a file and return the contents as a list of strings."""
    try:
        file = open(filename, 'r')
    # if it doesn't exist, finish game
    except FileNotFoundError:
        print('{} does not exist!'.format(filename))
        sys.exit()

        # array to store each individual line
    lines = []
    line = file.readline()

    # loop through each line and append to lines array
    while line:
        lines.append(line)
        line = file.readline()

    # return the grid
    return parse(lines)


def parse(lines):
    """Transform the input into a grid.

    Arguments:
            lines -- list of strings representing the grid

    Returns:
            list -- contains list of lists of Cells
    """

    # determine the number of columns and rows
    width = len(lines[0]) - 1  # to remove the newline
    height = len(lines)

    # initialise the matrix/grid with none values
    grid = [[None] * width for i in range(height)]

    # error checkers
    start_num = 0
    end_num = 0
    tele_check = []
    tele_nums = []
    mult_tele = False

    # loop through each cell in the grid
    for y in range(height):
        for x in range(width):
            if lines[y][x] == 'X':
                grid[y][x] = Start((x, y))
                start_num += 1
            elif lines[y][x] == 'Y':
                grid[y][x] = End((x, y))
                end_num += 1
            elif lines[y][x] == ' ':
                grid[y][x] = Air((x, y))
            elif lines[y][x] == '*':
                grid[y][x] = Wall((x, y))
            elif lines[y][x] == 'F':
                grid[y][x] = Fire((x, y))
            elif lines[y][x] == 'W':
                grid[y][x] = Water((x, y))
            elif lines[y][x].isdigit():
                grid[y][x] = Teleport((x, y), lines[y][x])
                # error checking for non matching teleport cells
                if lines[y][x] not in tele_check:
                    tele_check.append(lines[y][x])
                elif lines[y][x] in tele_nums:
                    mult_tele = True
                else:
                    tele_check.pop(tele_check.index(lines[y][x]))
                    tele_nums.append(lines[y][x])
            else:
                # if unrecognised letter appears
                raise ValueError(
                    'Bad letter in configuration file: {}.'.format(lines[y][x]))

    # check for single start and end pos, and matching teleport pads
    if start_num != 1:
        raise ValueError(
            'Expected 1 starting position, got {}.'.format(start_num))
    elif end_num != 1:
        raise ValueError(
            'Expected 1 ending position, got {}.'.format(end_num))
    elif tele_check or mult_tele:
        raise ValueError(
            'Teleport pad {} does not have an exclusively matching pad.'.format(
                tele_check[len(tele_check) - 1]))

    return grid


def nodeParse(grid):
    '''
    step through each cell in the grid and check if a node should be created
        criteria:
        - water/fire cell
        - teleport cell
        - start/end cell
        - branch in maze

    returns a list of nodes
    '''

    node_list = []
    height = len(grid)
    width = len(grid[0])

    for y in range(1, height - 1):
        for x in range(1, width - 1):

            # checks for start, end, fire, water, teleport
            if type(grid[y][x]) != Air and type(grid[y][x]) != Wall:
                node_list.append(Node((x, y)))
            # checks for branch/turn
            elif type(grid[y][x]) == Air:
                UD = type(grid[y + 1][x]) == type(grid[y - 1][x])
                LR = type(grid[y][x + 1]) == type(grid[y][x - 1])

                if not UD or not LR:
                    node_list.append(Node(grid[y][x]))

    return node_list
