def grid_to_string(grid, player):
    """Turns a grid and player into a string

    Arguments:
            grid -- list of list of Cells
            player -- a Player with water buckets

    Returns:
            string: A string representation of the grid and player.
    """

    grid_string = ''

    # loop through each in grid and check if player position matches
    for y in range(len(grid)):
        for x in range(len(grid[y])):
            # if match, overlay player position
            if x == player.col and y == player.row:
                grid_string += 'A'
            # else display base cell
            else:
                grid_string += grid[y][x].display
        grid_string += '\n'

    if player.num_water_buckets == 1:
        grid_string += '\nYou have 1 water bucket.'.format(
            player.num_water_buckets)
    else:
        grid_string += '\nYou have {} water buckets.'.format(
            player.num_water_buckets)

    return grid_string
