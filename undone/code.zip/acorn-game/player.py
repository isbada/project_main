class Player:
    def __init__(self, pos):
        self.display = 'A'
        self.num_water_buckets = 0
        self.col = pos[0]
        self.row = pos[1]

    def move(self, new_pos):
        self.col = new_pos[0]
        self.row = new_pos[1]

    def incWaterBuckets(self):
        self.num_water_buckets += 1

    def decWaterBuckets(self):
        self.num_water_buckets -= 1
