from game import Game
from cells import (
    Start,
    End,
    Air,
    Wall,
    Fire,
    Water,
    Teleport
)
import sys

# Checking command line inputs
argc = len(sys.argv)
if len(sys.argv) != 3:
    print('Usage: python3 run.py <filename> [play]')
    sys.exit()
elif sys.argv[2] != '[play]':
    print('Usage: python3 run.py <filename> [play]')
    sys.exit()

# Initialising game instance
game = Game(sys.argv[1], 'P')

# Find the Ending Position
end_pos = game.posTypeFind(End)

# Output the base maze
game.output()

# While the player position is not at end: game loop
while (game.player.col, game.player.row) != end_pos:
    move = input('Enter a move: ')
    game.gameMove(move.lower())
