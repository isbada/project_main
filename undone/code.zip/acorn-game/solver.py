from game import Game
from cells import (
    Start,
    End,
    Air,
    Wall,
    Fire,
    Water,
    Teleport
)
import sys

# Checking command line inputs
argc = len(sys.argv)
if len(sys.argv) != 3:
    print('Usage: python3 solver.py <filename> [mode]')
    sys.exit()
elif sys.argv[2] == '[DFS]':
    mode = 'D'
elif sys.argv[2] == '[BFS]':
    mode = 'B'
else:
    print('Usage: python3 solver.py <filename> [mode]')
    sys.exit()

# initialise the game object
game = Game(sys.argv[1], mode)


def solve(mode):
    pass


if __name__ == "__main__":
    solution_found = False
    if solution_found:
        pass
        # Print your solution...
    else:
        print("There is no possible path.")
