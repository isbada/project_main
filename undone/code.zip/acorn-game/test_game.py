from game import Game


def test_game():
    assert True


def run_tests():
    test_game()
