from grid import grid_to_string


def test_grid():
    assert True


def run_tests():
    test_grid()
