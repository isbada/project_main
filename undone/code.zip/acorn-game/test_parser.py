from game_parser import parse, read_lines


def test_parse():
    assert True


def run_tests():
    test_parse()
