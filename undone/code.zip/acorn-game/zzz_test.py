a = 1
b = 2

yes_no = (a == b)
print(yes_no)
